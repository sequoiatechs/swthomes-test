<aside id="sidebar" class="sidebar-white">
    <?php
    if( is_active_sidebar( 'agent-sidebar' ) ) {
        dynamic_sidebar( 'agent-sidebar' );
    }
    ?>
</aside>