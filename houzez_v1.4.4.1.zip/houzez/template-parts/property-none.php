<?php
/**
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 20/01/16
 * Time: 8:09 PM
 */
?>
<div class="item-wrap"><h4 class="not-found"><?php esc_html_e('Sorry No Results Found', 'houzez') ?></h4></div>
