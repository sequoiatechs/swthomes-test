<?php
/**
 * Top Bar Slogan
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 17/07/16
 * Time: 11:30 AM
 */
$top_bar_slogan = houzez_option('top_bar_slogan');
?>
<li><?php echo esc_attr($top_bar_slogan); ?></li>