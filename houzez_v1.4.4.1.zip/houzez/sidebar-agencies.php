<aside id="sidebar" class="sidebar-white">
    <?php
    if( is_active_sidebar( 'agency-sidebar' ) ) {
        dynamic_sidebar( 'agency-sidebar' );
    }
    ?>
</aside>