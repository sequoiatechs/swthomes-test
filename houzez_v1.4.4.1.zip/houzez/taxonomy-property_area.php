<?php
/**
 * Taxonomy Property Feature
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 08/01/16
 * Time: 4:26 PM
 */
get_header();

get_template_part("template-parts/common-taxonomy");

get_footer();